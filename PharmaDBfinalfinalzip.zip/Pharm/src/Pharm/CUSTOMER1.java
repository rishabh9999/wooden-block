package Pharm;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
 
public class CUSTOMER1 extends JFrame implements ActionListener {
 
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//Initializing Components
    JLabel lb, lb1, lb2, lb3, lb4, lb5,lb6,lb7,lbx;
    JTextField tf,tf1, tf2, tf3, tf4, tf5,tf6,tf7,tfx;
    JButton btn;
 
    //Creating Constructor for initializing JFrame components
    CUSTOMER1() {
     
        lb = new JLabel("Enter Drug Name:");
        lb.setBounds(20, 20, 100, 20);
        tf = new JTextField(20);
        tf.setBounds(130, 20, 200, 20);
 
        btn = new JButton("Submit");
        btn.setBounds(30, 49, 100, 20);
        btn.addActionListener(this);
 
        lb1 = new JLabel("DRUG info");
        lb1.setBounds(30, 80, 450, 30);
        lb1.setForeground(new Color(0, 0, 205));
        lb1.setFont(new Font("Serif", Font.BOLD, 20));
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(381, 313);
 
        lb2 = new JLabel("Drug Name:");/*Drug Name	Chemical Composition	Brand	Batch Number	Expiry Date	Supplied by	Price*/
        lb2.setBounds(20, 120, 110, 20);
        tf2 = new JTextField(50);
        tf2.setBounds(155, 120, 200, 20);
        
        lb3 = new JLabel("Chemical Composition:");
        lb3.setBounds(20, 150, 137, 30);
        tf3 = new JTextField(100);
        tf3.setBounds(155, 155, 200, 20);
        
        lb4 = new JLabel("Brand:");
        lb4.setBounds(20, 180, 100, 20);
        tf4 = new JTextField(50);
        tf4.setBounds(155, 180, 200, 20);
        
       
        
        lb7 = new JLabel("Price:");
        lb7.setBounds(20, 211, 100, 20); 
        tf7 = new JTextField(50);
        tf7.setBounds(155, 211, 200, 20);
        
        
       getContentPane().setLayout(null);
 
        //Add components to the JFrame
        getContentPane().add(lb);
        getContentPane().add(tf);
        getContentPane().add(btn);
 
        getContentPane().add(lb1);
        //add(lb);
       // add(tf1);
        getContentPane().add(lb2);
        getContentPane().add(tf2);
        getContentPane().add(lb3);
        getContentPane().add(tf3);
        getContentPane().add(lb4);
        getContentPane().add(tf4);
       // getContentPane().add(lb5);
       //getContentPane().add(tf5);
        //getContentPane().add(lb6);
        //getContentPane().add(tf6);
        getContentPane().add(lb7);
        getContentPane().add(tf7);
        
        
 
       
        
        
    }
 
    public void actionPerformed(ActionEvent e) {
        //Create DataBase Coonection and Fetching Records
           
        try {
            String str = tf.getText();
         str.equalsIgnoreCase(str);
 
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb", "root", "");
            CallableStatement st = con.prepareCall("CALL dinfo(?)");
            st.setString(1, str);
            
 
           
            ResultSet rs = st.executeQuery();
           
            //rs.next();
         if (rs.next()) {
                String s = rs.getString(1);
                String s1 = rs.getString(2);
                String s2 = rs.getString(3);
                //String s3 = rs.getString(4);
                //String s4 = rs.getString(5);
                String s5 = rs.getString(6);
 
                //Sets Records in TextFields.
                tf2.setText(s);
                tf3.setText(s1);
                tf4.setText(s2);
                //tf5.setText(s3);
                //tf6.setText(s4);
                tf7.setText(s5);
                //Set TextField Editable False
                // tf1.setEditable(false);
                 tf2.setEditable(false);
                 tf3.setEditable(false);
                 tf4.setEditable(false);
                // tf5.setEditable(false);
                 //tf6.setEditable(false);
                 tf7.setEditable(false);
            } else {
            	tf2.setText("");
                tf3.setText("");
                tf4.setText("");
              // tf5.setText("");
                //tf6.setText("");
                tf7.setText("");
                JOptionPane.showMessageDialog(null, "Drug not Found");
            }
 
            //Create Exception Handler
        } catch (Exception ex) {
 
            System.out.println(ex);
        }
    }
//Running Constructor
 
    public static void main(String args[]) {
        new CUSTOMER1();
    }
} 