package Pharm;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;

import javax.swing.JTextField;
import javax.swing.JButton;
//import javax.swing.JTable;
//import javax.swing.JList;
//import javax.swing.JMenu;
//import javax.swing.JProgressBar;

public class Orders extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Orders frame = new Orders();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Orders() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Manage Orders");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel.setBounds(158, 11, 196, 44);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Drug Name");
		lblNewLabel_1.setBounds(41, 73, 105, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Quantity");
		lblNewLabel_2.setBounds(41, 98, 105, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Distributor Name");
		lblNewLabel_3.setBounds(41, 123, 122, 14);
		contentPane.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(205, 66, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(205, 95, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(205, 121, 86, 17);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("Place Order");
		btnNewButton.setBounds(95, 158, 122, 23);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent ae){ 
        if(ae.getActionCommand().equals("Place Order"))
   {
       //System.out.println("asdgg");
      
      String Drug_Name=textField.getText();
       String Distributor_Name=textField_2.getText();
       String Quantity =textField_1.getText();
      
       
       
    
       try{
       
    	   Class.forName("com.mysql.jdbc.Driver");

        //System.out.println("class for name");
        java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb","root","");
        java.sql.Statement s=con.createStatement();
        String sql= "INSERT INTO orders VALUES ('"+Drug_Name+"','"+Quantity+"','"+Distributor_Name+"')";
        
        	
        //System.out.println(sql);
        s.executeUpdate(sql);
        JOptionPane.showMessageDialog(null,"Order Placed!!");
        textField.setText("");
        textField_1.setText("");
        textField_2.setText("");
        //textField_3.setText("");
        //textField_4.setText("");
       
        con.close();
   }
       catch(Exception ee)
       {
           System.out.println("error occured  "  + ee);
       }
      
   }

}
}
