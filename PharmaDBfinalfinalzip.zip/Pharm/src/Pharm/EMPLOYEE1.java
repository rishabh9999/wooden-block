package Pharm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FontMetrics;
import java.awt.Graphics2D;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.text.Caret;
import javax.swing.text.Document;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

import com.mysql.jdbc.ResultSetMetaData;
import com.mysql.jdbc.Statement;

public class EMPLOYEE1 extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField10;
	private JTextField textField11;
	private JTextField textField12;
	private JTextField textField13;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EMPLOYEE1 frame = new EMPLOYEE1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EMPLOYEE1() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 762, 479);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblInvoice = new JLabel("Invoice");
		lblInvoice.setForeground(new Color(0, 0, 255));
		lblInvoice.setBounds(5, 5, 419, 27);
		lblInvoice.setHorizontalAlignment(SwingConstants.CENTER);
		lblInvoice.setFont(new Font("Times New Roman", Font.BOLD, 22));
		contentPane.add(lblInvoice);
		
		JLabel lblNewLabel = new JLabel("Bill ID");
		lblNewLabel.setBounds(33, 43, 60, 14);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(170, 43, 60, 14);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Drug Name");
		lblNewLabel_1.setBounds(33, 75, 86, 14);
		contentPane.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(170, 75, 114, 14);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Chemical Composition");
		lblNewLabel_2.setBounds(33, 111, 137, 14);
		contentPane.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(170, 107, 121, 14);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Brand");
		lblNewLabel_3.setBounds(33, 136, 86, 14);
		contentPane.add(lblNewLabel_3);
		
		
		
		textField_3 = new JTextField();
		textField_3.setBounds(170, 133, 121, 14);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblBatchNumber = new JLabel("Batch Number");
		lblBatchNumber.setBounds(33, 164, 86, 14);
		contentPane.add(lblBatchNumber);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(170, 161, 121, 14);
		contentPane.add(textField_4);
		
		JLabel lblExpiryDate = new JLabel("Expiry Date");
		lblExpiryDate.setBounds(33, 192, 79, 14);
		contentPane.add(lblExpiryDate);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(170, 189, 114, 14);
		contentPane.add(textField_5);
		
		JLabel lblNewLabel_4 = new JLabel("Price");
		lblNewLabel_4.setBounds(33, 217, 79, 14);
		contentPane.add(lblNewLabel_4);
		
		textField_6 = new JTextField();
		textField_6.setBounds(170, 213, 146, 18);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(33, 251, 110, 14);
		contentPane.add(lblQuantity);
		
		textField_8 = new JFormattedTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(170, 249, 146, 18);
		contentPane.add(textField_8);
		
		JLabel lblAmount = new JLabel("Amount");
		lblAmount.setBounds(33, 291, 110, 14);
		contentPane.add(lblAmount);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(170, 289, 146, 18);
		contentPane.add(textField_7);
		
		JButton btnNewButton = new JButton("Generate invoice");
		btnNewButton.setBounds(228, 361, 131, 54);
		contentPane.add(btnNewButton);
		
		btnNewButton.addActionListener(new ActionListener(){
  		    public void actionPerformed(ActionEvent e){
  		       if(e.getActionCommand().equals("Generate invoice"))
  		     {
  		      
  		         try{
  		        	
  		        	
  		        	 String str=textField.getText();
  		        	Class.forName("com.mysql.jdbc.Driver");
  		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb", "root", "");
  		            PreparedStatement st = con.prepareStatement("select Drug_Name,Chemical_Composition,Brand,Batch_Number,Expiry_Date,Price,Quantity,Amount from invoice where Bill_ID=?;");
  		            
  		          st.setString(1, str);
  		          ResultSet rs = st.executeQuery();
                  
  		        // It creates and displays the table
  		       
  				
  				
  		        
  		     
  		    JLabel lblNewLabel = new JLabel("Bill ID:");
	  		lblNewLabel.setBounds(28, 39, 86, 26);
	  		contentPane.add(lblNewLabel);
	  		
	  		textField10 = new JTextField();
	  		textField10.setBounds(84, 36, 60, 80);
	  		contentPane.add(textField10);
	  		textField10.setColumns(10);
	  		
	  		JLabel lblNewLabel11 = new JLabel("Customer Name:");
	  		lblNewLabel11.setBounds(28, 64, 86, 26);
	  		contentPane.add(lblNewLabel11);
	  		
	  		textField11 =new JTextField();
	  		textField11.setBounds(84, 61,60,100);
	  		contentPane.add(textField11);
	  		textField11.setColumns(10);
	  		
	  		JLabel lblNewLabel12 = new JLabel("Date and Time:");
	  		lblNewLabel12.setBounds(28, 64, 86, 26);
	  		contentPane.add(lblNewLabel12);
	  		
	  		textField12 =new JTextField();
	  		textField12.setBounds(84, 61,100,150);
	  		contentPane.add(textField12);
	  		textField12.setColumns(15);
	  		
	  		Calendar cal = Calendar.getInstance();
	  		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	  	   textField12.setText(dateFormat.format(cal.getTime()));
	  	   textField12.setEditable(false);
	  		
	  		textField10.setText(textField.getText());
	  		textField10.setEditable(false);
	  		
	  		
	  		
	  		JPanel panel3=new JPanel();
	  		
	  		panel3.add(lblNewLabel);
	  		panel3.add(textField10);
	  		panel3.add(lblNewLabel11);
	  		panel3.add(textField11);
	  		panel3.add(lblNewLabel12);
	  		panel3.add(textField12);
	  		
	  		
	  		
	  		//JPanel panel=new JPanel();
	  		//JPanel panel1=new JPanel();
	  		
	  		
	  		//lblNewLabel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
	  		
	  		JTable table = new JTable(buildTableModel(rs));
	  		
	  		JPanel panel1=new JPanel();
	  	   JLabel lblNewLabel13 = new JLabel("Total Amount:");
	  		lblNewLabel13.setBounds(28, 39, 86, 26);
	  		contentPane.add(lblNewLabel13);
	  		
	  		textField13 = new JTextField();
	  		textField13.setBounds(84, 36, 60, 80);
	  		contentPane.add(textField13);
	  		textField13.setColumns(10);
	  		
	  		
	  		panel1.add(lblNewLabel13);
	  		panel1.add(textField13);
	  		
	  		 try{
	  			 String str1=textField10.getText();
	        	Class.forName("com.mysql.jdbc.Driver");
	            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb", "root", "");
	            PreparedStatement st1 = con1.prepareStatement("select Total_amount from total_amount where Bill_ID=?;");
	            st1.setString(1,str1);
	            //System.out.println(str1);
	         
	          ResultSet rs1 = st1.executeQuery();
	         
	         
             	       
	         if(rs1.next())
	         {
	        	 String s9= rs1.getString(1);
	        	 //System.out.println(s9);
		  			textField13.setText("Rs "+s9);
		  			textField13.setEditable(false);
		  			
	         }
		  		
	          
	  		 }
	  		 catch(Exception ee)
	  		 {
	  			 System.out.println(ee);
	  		 }
	  		
	  		 
	  		 
	          
	          
	  		
		        

		        // Closes the Connection
		     // table.setPreferredSize(new Dimension(1000,500));
	  		JFrame frame=new JFrame();
	  		
	  		
	  		frame.setVisible(true);
	  		frame.setTitle("The Rx Pharmacy");
	  		
	  		frame.setSize(1000,600);
	  		frame.setFont(new Font("System", Font.BOLD, 18));
	  		Font f = frame.getFont();
	  		FontMetrics fm = frame.getFontMetrics(f);
	  		int x = fm.stringWidth("The Rx Pharmacy");
	  		int y = fm.stringWidth(" ");
	  		int z = frame.getWidth()/2 - (x/2);
	  		int w = z/y;
	  		String pad =" ";
	  		//for (int i=0; i!=w; i++) pad +=" "; 
	  		pad = String.format("%"+w+"s", pad);
	  		frame.setTitle(pad+"The Rx Pharmacy");
	  		
	  		
	  		//frame.getContentPane().add(panel2,BorderLayout.TITLE);
	  		frame.getContentPane().add(panel3,BorderLayout.NORTH);
	  		
	  		frame.getContentPane().add(new JScrollPane(table),BorderLayout.CENTER);
	  		frame.getContentPane().add(panel1,BorderLayout.SOUTH);
	  		//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
	  		
  		
  		          
  		         
  		          con.close();
  		     }
  		         catch(Exception ee)
  		         {
  		             System.out.println("error occured  "  + ee);
  		         }
  		        
  		     }
  		        //textfield.setText(null); //or use this
  		    }

  		  public DefaultTableModel buildTableModel(ResultSet rs)
  		        throws Exception {

  		    java.sql.ResultSetMetaData metaData = rs.getMetaData();
  		  

  		    // names of columns
  		    Vector<String> columnNames = new Vector<String>();
  		    int columnCount = metaData.getColumnCount();
  		    for (int column = 1; column <= columnCount; column++) {
  		        columnNames.add(metaData.getColumnName(column));
  		    }

  		    // data of the table
  		    Vector<Vector<Object>> data = new Vector<Vector<Object>>();
  		    while (rs.next()) {
  		        Vector<Object> vector = new Vector<Object>();
  		        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
  		            vector.add(rs.getObject(columnIndex));
  		        }
  		        data.add(vector);
  		    }
  		 
  		  
	        

  		    return new DefaultTableModel(data, columnNames);

  		}
  		});
		
		
   		  
		
		
		
		JButton btnNewButton_2 = new JButton("Submit");
   		btnNewButton_2.setBounds(33, 361, 86, 54);
   		contentPane.add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener(){
      		    public void actionPerformed(ActionEvent e){
      		       if(e.getActionCommand().equals("Submit"))
      		     {
      		         String billid,dname,cc,brand,bnumber,expirydate,price,qty,amount;
      		         int quantity=0;
      		         billid=textField.getText();
      		         dname=textField_1.getText();
      		         cc=textField_2.getText();
      		         brand=textField_3.getText();
      		         bnumber=textField_4.getText();
      		         expirydate=textField_5.getText();
      		         price=textField_6.getText();
      		         qty=textField_8.getText();
      		         amount=textField_7.getText();
      		         
      		        // System.out.println("Testing");
      		      
      		         try{
      		         
      		      	   Class.forName("com.mysql.jdbc.Driver");

      		          //System.out.println("class for name");
      		          java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb","root","");
      		          
      		        PreparedStatement st = con.prepareStatement("select QTY from drug_info where Drug_Name=? and Batch_Number=?;");
  		            
	  		          st.setString(1,dname);
	  		          st.setString(2,bnumber);
	  		          ResultSet rs=st.executeQuery();
	  		          if(rs.next())
	  		          {
	  		        	   quantity=rs.getInt(1);
	  		          }
  		         //System.out.println(quantity);
	  		          int QQQT=0;
	  		          if((Integer.valueOf(qty)-quantity)>0)
	  		          {
	  		        	  QQQT=quantity;
	  		        	  quantity=0;
	  		          }
	  		          else
	  		          {
	  		        	  quantity-=Integer.valueOf(qty);
	  		        	  QQQT=Integer.valueOf(qty);
	  		          }
	  		          
	  		        
	  		      if(quantity==0&&QQQT==0)
		          {
		        	JOptionPane.showMessageDialog(null, "Out of stock!!");
		        	Class.forName("com.mysql.jdbc.Driver");
  		            Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb", "root", "");
  		            
  		            PreparedStatement st123 = con2.prepareStatement("delete from drug_info where Drug_Name=? and Batch_Number=?;");
  		            
  		          st123.setString(1,dname);
  		          st123.setString(2,bnumber);
  		            
  		         int val=st123.executeUpdate();
		          }

	  		      else
	  		      {
	  		        PreparedStatement st1 = con.prepareStatement("update drug_info set QTY='"+quantity+"' where Drug_Name=? and Batch_Number=?;");
		              st1.setString(1,dname);
		              st1.setString(2,bnumber);
	  		          int val1=st1.executeUpdate();
	  		          System.out.println(val1);
                  
	  		         
	  		      
      		        
      		          
      		          
      		          
      		          java.sql.Statement s=con.createStatement();
      		          
      		        
      		          String sql= "INSERT INTO invoice VALUES ('"+billid+"','"+dname+"','"+cc+"','"+brand+"','"+bnumber+"','"+expirydate+"','"+price+"','"+QQQT+"','"+amount+"')";
      		          //System.out.println(sql);
      		          s.executeUpdate(sql);
      		          
      		          
      		          
      		          JOptionPane.showMessageDialog(null,QQQT+" "+dname+" added!");
      		          
      		  
      		          
      		        textField_1.setText("");
    		        textField_2.setText("");
    		        textField_3.setText("");
    		        textField_4.setText("");
    		        textField_5.setText("");
    		        textField_6.setText("");
    		        textField_7.setText("");
    		        textField_8.setText("");
    		        
    		        
	  		      } 
      		          
      		         
      		          con.close();
      		     }
      		         catch(Exception ee)
      		         {
      		             System.out.println("error occured  "  + ee);
      		         }
      		        
      		     }
      		        //textfield.setText(null); //or use this
      		    }
      		});
           
		
		JButton btnNewButton_3 = new JButton("Go");
		btnNewButton_3.setBounds(299, 71, 51, 23);
		contentPane.add(btnNewButton_3);
		btnNewButton_3.addActionListener(this);
		
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.setBounds(129, 361, 89, 54);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
		        textField.setText("");
		        textField_1.setText("");
		        textField_2.setText("");
		        textField_3.setText("");
		        textField_4.setText("");
		        textField_5.setText("");
		        textField_6.setText("");
		        textField_7.setText("");
		        textField_8.setText("");
		        
		        //textfield.setText(null); //or use this
		    }
		});

		
		JButton btnNewButton_4 = new JButton("Back");
		btnNewButton_4.setBounds(670, 11, 66, 23);
		contentPane.add(btnNewButton_4);
		
		JLabel label = new JLabel("Manage Orders");
		label.setForeground(new Color(0, 128, 0));
		label.setFont(new Font("Times New Roman", Font.BOLD, 18));
		label.setBounds(488, -2, 196, 44);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Drug Name");
		label_1.setBounds(396, 50, 105, 14);
		contentPane.add(label_1);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(560, 43, 86, 20);
		contentPane.add(textField_9);
		
		JLabel label_2 = new JLabel("Quantity");
		label_2.setBounds(396, 75, 105, 14);
		contentPane.add(label_2);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(560, 72, 86, 20);
		contentPane.add(textField_10);
		
		JLabel label_3 = new JLabel("Distributor Name");
		label_3.setBounds(396, 100, 122, 14);
		contentPane.add(label_3);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(560, 98, 86, 17);
		contentPane.add(textField_11);
		
		JButton button = new JButton("Place Order");
		button.setBounds(450, 135, 122, 23);
		contentPane.add(button);
		button.addActionListener(this);
		
		
		
		
		
		btnNewButton_4.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
		    	
		       Registration r1=new Registration();
		       r1.setVisible(true);
		     dispose();
		  
		        
		        //textfield.setText(null); //or use this
		    }
		});
		
		
       
		
		
		
	}
	
	
	public void actionPerformed(ActionEvent e) {
        //Create DataBase Coonection and Fetching Records
           if(e.getActionCommand().equals("Go"))
           { 	   
        try {
            String str = textField_1.getText();
         str.equalsIgnoreCase(str);
 
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb", "root", "");
            PreparedStatement st = con.prepareStatement("select * from drug_info where Drug_Name=?;");
            st.setString(1, str);
 
            //Excuting Query
            ResultSet rs = st.executeQuery();
 
            if (rs.next()) {
               // String s = rs.getString(1);
                String s1 = rs.getString(2);
                String s2 = rs.getString(3);
                String s3 = rs.getString(4);
                String s4 = rs.getString(5);
                String s5 = rs.getString(6);
                
                textField_2.setEditable(false);
                textField_3.setEditable(false);
                textField_4.setEditable(false);
                textField_5.setEditable(false);
               textField_6.setEditable(false);
                //Sets Records in TextFields.
                //textField_1.setText(s);
               
                textField_2.setText(s1);
                textField_3.setText(s2);
                textField_4.setText(s3);
                textField_5.setText(s4);
               textField_6.setText(s5);
               
               
               
               
               textField_8.addActionListener(new ActionListener(){
       		    public void actionPerformed(ActionEvent e){
       		    	float PRICE=Float.valueOf(textField_6.getText());
                    int QUANTITY=Integer.valueOf(textField_8.getText());
                    
       		    	double AMOUNT=PRICE*QUANTITY;
       		    	AMOUNT=Math.floor(AMOUNT);
       		    	//System.out.println(Math.round(AMOUNT));
                    String s6=String.valueOf(AMOUNT);
       		    	textField_7.setText(s6);
       		        //textfield.setText(null); //or use this
       		    }
       		});
               
               
               
                
                                
                //textField_2.setText(s);

            } else {
            	textField_1.setText("");
                textField_2.setText("");
                textField_3.setText("");
                textField_4.setText("");
                textField_5.setText("");
                textField_6.setText("");
                textField_7.setText("");
                textField_8.setText("");
                JOptionPane.showMessageDialog(null, "Drug not Found");
            }
 
            //Create Exception Handler
        } catch (Exception ex) 
        {
 
            System.out.println(ex);
        }
    
        
     
           }
           
           
           

           if(e.getActionCommand().equals("Place Order"))
      {
          //System.out.println("asdgg");
         
         String Drug_Name=textField_9.getText();
          String Distributor_Name=textField_11.getText();
          String Quantity =textField_10.getText();
         
          
          
       
          try{
          
       	   Class.forName("com.mysql.jdbc.Driver");

           //System.out.println("class for name");
           java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb","root","");
           java.sql.Statement s=con.createStatement();
           String sql= "INSERT INTO orders VALUES ('"+Drug_Name+"','"+Quantity+"','"+Distributor_Name+"')";
           
           	
           //System.out.println(sql);
           s.executeUpdate(sql);
           JOptionPane.showMessageDialog(null,"Order Placed!!");
           textField_9.setText("");
           textField_10.setText("");
           textField_11.setText("");
           //textField_3.setText("");
           //textField_4.setText("");
          
           con.close();
      }
          catch(Exception ee)
          {
              System.out.println("error occured  "  + ee);
          }
         
      }
    }
	
	
	


}
