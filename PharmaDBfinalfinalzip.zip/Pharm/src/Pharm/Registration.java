package Pharm;

import java.awt.BorderLayout;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.AbstractAction;

import java.awt.event.ActionEvent;

import javax.swing.Action;

import java.awt.event.ActionListener;
import java.sql.DriverManager;

import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;

public class Registration extends JFrame implements ActionListener {

	//private static final String EmailAddress = null;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	
	public String Username,Password,Name,EmailAddress,PhoneNumber,varName,CORE;
	private final Action action = new SwingAction();
	//private final Action action = new Action();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration frame = new Registration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	/*public void SUBMIT(String query){
		
	try{
        Class.forName("com.mysql.jdbc.Driver");

         //System.out.println("class for name");
         java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb","root","");
         java.sql.Statement s=con.createStatement();
         //String query= "INSERT INTO registeration values ('"+Username+"','"+Password+"','"+Address+"','"+PhoneNumber+"','"+EmailAddress+"')";
         //System.out.println(query);
         s.executeUpdate(query);
         con.close();
    }
        catch(Exception ee)
        {
            System.out.println("error occured  "  + ee);
        }
	}*/
	public  Registration() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 576, 451);
		contentPane = new JPanel();
		contentPane.setForeground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTheRxPharmacy = new JLabel("The Rx Pharmacy");
		lblTheRxPharmacy.setBounds(128, 27, 312, 41);
		lblTheRxPharmacy.setFont(new Font("Monotype Corsiva", Font.BOLD, 35));
		lblTheRxPharmacy.setForeground(Color.RED);
		contentPane.add(lblTheRxPharmacy);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setBounds(41, 118, 86, 26);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(141, 124, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblAge = new JLabel("Password");
		lblAge.setBounds(41, 155, 86, 14);
		contentPane.add(lblAge);
		
		textField_1 = new JPasswordField();
		textField_1.setBounds(141, 152, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblAddress = new JLabel("Name");
		lblAddress.setBounds(41, 180, 86, 14);
		contentPane.add(lblAddress);
		
		textField_2 = new JTextField();
		textField_2.setBounds(141, 177, 86, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Phone Number");
		lblNewLabel_1.setBounds(41, 205, 86, 26);
		contentPane.add(lblNewLabel_1);
		
		textField_3 = new JTextField();
		textField_3.setBounds(141, 208, 86, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblEmailId = new JLabel("Email Address");
		lblEmailId.setBounds(41, 241, 86, 17);
		contentPane.add(lblEmailId);
		
		textField_4 = new JTextField();
		textField_4.setBounds(141, 239, 86, 20);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setBounds(138, 270, 89, 23);
		contentPane.add(btnReset);
		
		btnReset.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
		        textField.setText("");
		        textField_1.setText("");
		        textField_2.setText("");
		        textField_3.setText("");
		        textField_4.setText("");
		        //textfield.setText(null); //or use this
		    }
		});
		
		
		
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(308, 124, 86, 34);
		contentPane.add(lblUsername);
		
		textField_5 = new JTextField();
		textField_5.setBounds(416, 131, 86, 20);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(308, 165, 68, 14);
		contentPane.add(lblPassword);
		
		textField_6 = new JPasswordField();
		textField_6.setBounds(416, 162, 86, 20);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		



 // added code

		//System.out.println(rdbtnNewRadioButton.getText());
		
	
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(41, 270, 89, 23);
		contentPane.add(btnSubmit);
		btnSubmit.addActionListener(this);
		// JOptionPane.showMessageDialog(null, "Successfully registered");
		
		JLabel lblNewLabel_2 = new JLabel("New Customer? Register now ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(32, 79, 219, 31);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Already registered? Login right away!");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_3.setBounds(278, 79, 232, 55);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton_1 = new JButton("Exit");
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(arg0.getActionCommand().equals("Exit"))
				{
					System.exit(0);
				}
			}
		});
		btnNewButton_1.setBounds(225, 331, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_4 = new JLabel("Select Login Type");
		lblNewLabel_4.setBounds(308, 196, 102, 14);
		contentPane.add(lblNewLabel_4);
		
		final JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"Admin", "Employee", "Customer"}));
		comboBox.setBounds(416, 190, 86, 26);
		contentPane.add(comboBox);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(305, 224, 89, 23);
		contentPane.add(btnLogin);
		btnLogin.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae)
			{
				if(ae.getActionCommand().equals("Login"))
		        {   
		        	 
		        	
		        	String Username=textField_5.getText();
		            String Password=textField_6.getText();
		           // String CorE=textField_8.getText();
		            String uname;
		            String pass;
		            comboBox.setRenderer(new PromptComboBoxRenderer("Select"));
		    		//comboBox.setSelectedIndex(-1);
		    	 varName = (String) comboBox.getSelectedItem();
		    	
		    	 
		    	 System.out.println(varName);
		            
		            
		            try{
		            	
		         	   Class.forName("com.mysql.jdbc.Driver");

		             //System.out.println("class for name");
		             java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb","root","");
		            // java.sql.Statement c=con.createStatement();
		             java.sql.ResultSet rs;
		             java.sql.PreparedStatement smt=null;
		             
		            // String sql= "";
		             smt=con.prepareStatement("Select * from registeration where Username=? and Password=? and CorE=?;");
		             smt.setString(1,Username);
		             smt.setString(2,Password);
		             smt.setString(3,varName);
		             
		             //System.out.println(sql);
		            rs=smt.executeQuery();
		            //this.CorE=CorE;
		             //rs.next();
		             if(rs.next())
		             {    
		            	  uname=rs.getString(1);
		            	  pass=rs.getString(2);
		            	CORE=rs.getString(6);
		            	
		            	  
		            	 // System.out.println(uname+" "+pass+" "+CORE);
		            	  //System.out.println(uname+" "+pass);
		            	 if(uname.equals(Username) && pass.equals(Password) && CORE.equals("Customer"))
		            	 {  //System.out.println(Username+" "+Password+" "+CorE);
		            		// JFrame CUSTOMER1;
		            		 
		            	        //textField_8.setText("");
		            		 CUSTOMER1 cust=new CUSTOMER1();
		            		 textField_5.setText("");
		 		  	        textField_6.setText("");
		            		 cust.setVisible(true);
		            		 //dispose();
		            		 
		            	 }
		            	 else if (uname.equals(Username) && pass.equals(Password) && CORE.equals("Employee"))
		            	 {
		            		 
		         	        //textField_8.setText("");
		         	        EMPLOYEE1 e1=new EMPLOYEE1();
		         	       textField_5.setText("");
				  	        textField_6.setText("");
		         	        e1.setVisible(true);
		         	        //dispose();
		            	 }
		            	 else if(uname.equals(Username) && pass.equals(Password) && CORE.equals("Admin"))
		            	 {
		            		 ADMIN a1=new ADMIN();
		            		 textField_5.setText("");
					  	        textField_6.setText("");
		            		 a1.setVisible(true);
		            	 }
		            	 
		            	 
		            	 
		            	
		             }
		             else
		             {
		          	   JOptionPane.showMessageDialog(null,"Username/Password is wrong!!");
		          	 textField_5.setText("");
		  	        textField_6.setText("");
		  	       // textField_8.setText("");
		          	   
		             }

			
		            con.close();
		        }
		            catch(Exception ee)
		            {
		                System.out.println("error occured  "  + ee);
		            }
		            
		        }}
		});
		
		
	 //comboBox.setVisible(true);
	// System.out.println(varName);
		//String value = comboBox.getSelectedItem().toString();
	
		
		

		
	
		
		
		
		
	}
	
	public void actionPerformed(ActionEvent ae){ 
        if(ae.getActionCommand().equals("Submit"))
   {
       //System.out.println("asdgg");
      
      String Username=textField.getText();
       String Password=textField_1.getText();
       String Name =textField_2.getText();
      String PhoneNumber=textField_3.getText();
       String EmailAddress=textField_4.getText();
       //String CorE="Customer";
       
       System.out.println("Testing");
    
       try{
       
    	   Class.forName("com.mysql.jdbc.Driver");

        //System.out.println("class for name");
        java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb","root","");
        java.sql.Statement s=con.createStatement();
        String sql= "INSERT INTO registeration(Username,Password,Name,PhoneNumber,EmailAddress) VALUES ('"+Username+"','"+Password+"','"+Name+"','"+PhoneNumber+"','"+EmailAddress+"')";
        //System.out.println(sql);
        s.executeUpdate(sql);
        JOptionPane.showMessageDialog(null,"Successfully registered");
        textField.setText("");
        textField_1.setText("");
        textField_2.setText("");
        textField_3.setText("");
        textField_4.setText("");
       
        con.close();
   }
       catch(Exception ee)
       {
           System.out.println("error occured  "  + ee);
       }
      
   }
        /* if(ae.getActionCommand().equals("Login"))
        {   
        	 
        	 comboBox.setRenderer(new PromptComboBoxRenderer("Select"));
    		 comboBox.setSelectedIndex(-1);
    	 varName = (String) comboBox.getSelectedItem();
    	
    	 
    	 System.out.println(varName);
        	String Username=textField_5.getText();
            String Password=textField_6.getText();
           // String CorE=textField_8.getText();
            String uname;
            String pass;
            
            
            try{
            	
         	   Class.forName("com.mysql.jdbc.Driver");

             //System.out.println("class for name");
             java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb","root","");
            // java.sql.Statement c=con.createStatement();
             java.sql.ResultSet rs;
             java.sql.PreparedStatement smt=null;
             
            // String sql= "";
             smt=con.prepareStatement("Select * from registeration where Username=? and Password=?;");
             smt.setString(1,Username);
             smt.setString(2,Password);
             
             //System.out.println(sql);
            rs=smt.executeQuery();
            //this.CorE=CorE;
             //rs.next();
             if(rs.next())
             {    
            	  uname=rs.getString(1);
            	  pass=rs.getString(2);
            	 // String CORE=rs.getString(6);
            	  
            	 // System.out.println(uname+" "+pass+" "+CORE);
            	  //System.out.println(uname+" "+pass);
            	 if(uname.equals(Username) && pass.equals(Password)&&varName.equals("Customer"))
            	 {  //System.out.println(Username+" "+Password+" "+CorE);
            		// JFrame CUSTOMER1;
            		 
            	        //textField_8.setText("");
            		 CUSTOMER1 cust=new CUSTOMER1();
            		 cust.setVisible(true);
            		 dispose();
            		 
            	 }
            	 else if (uname.equals(Username) && pass.equals(Password)&&varName.equals("Employee"))
            	 {
            		 
         	        //textField_8.setText("");
         	        EMPLOYEE1 e1=new EMPLOYEE1();
         	        e1.setVisible(true);
         	        dispose();
            	 }
            	 
            	 
            	 
            	 
            	
             }
             else
             {
          	   JOptionPane.showMessageDialog(null,"Username/Password is wrong!!");
          	 textField_5.setText("");
  	        textField_6.setText("");
  	       // textField_8.setText("");
          	   
             }
            
        	 
        		 
        	 
             //JOptionPane.showMessageDialog(null,"Successfully registered");
            
             con.close();
        }
            catch(Exception ee)
            {
                System.out.println("error occured  "  + ee);
            }
            
        }
        
        	//JOptionPane.showMessageDialog(null,"Username/Password is wrong!!");
        
        
        
	/*private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}*/
}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}

