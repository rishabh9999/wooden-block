package Pharm;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;

public class ADMIN extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ADMIN frame = new ADMIN();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ADMIN() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 723, 477);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblViewRegisteredUsers = new JLabel("Registered users");
		lblViewRegisteredUsers.setForeground(new Color(0, 0, 0));
		lblViewRegisteredUsers.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblViewRegisteredUsers.setBounds(69, 11, 247, 50);
		contentPane.add(lblViewRegisteredUsers);
		
		JLabel lblNewLabel = new JLabel("Drug inventory");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblNewLabel.setBounds(434, 11, 166, 50);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("View registered \r\nuser's details");
		btnNewButton.setBounds(44, 161, 232, 61);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
	  		       if(e.getActionCommand().equals("View registered \r\nuser's details"))
	  		     {
	  		    	 try{
	  		    		 
	  		    		Class.forName("com.mysql.jdbc.Driver");
	  		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb", "root", "");
	  		            PreparedStatement st = con.prepareStatement("select * from registeration;");
	  		            
	  		            
	  		          ResultSet rs = st.executeQuery();
	  		        JTable table = new JTable(buildTableModel(rs));
	  		        
	  		      JFrame frame=new JFrame();
	  	  	      frame.setVisible(true);
	  	  	      frame.getContentPane().add(new JScrollPane(table),BorderLayout.CENTER);
	  	  	  frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
	  	  	              con.close();
	  	  		
	  		    	 }
	  		    	 catch(Exception ee)
	  		    	 {
	  		    		 System.out.println(ee);
	  		    	 }
	  		     }
			}
			
			
			
		});
		
		JButton btnNewButton_1 = new JButton("View drug database");
		btnNewButton_1.setBounds(370, 366, 258, 61);
		contentPane.add(btnNewButton_1);
		
		JLabel label = new JLabel("Drug Name");
		label.setBounds(370, 72, 86, 14);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(507, 72, 114, 14);
		contentPane.add(textField);
		
		JLabel label_1 = new JLabel("Chemical Composition");
		label_1.setBounds(370, 108, 137, 14);
		contentPane.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(507, 104, 121, 14);
		contentPane.add(textField_1);
		
		JLabel label_2 = new JLabel("Brand");
		label_2.setBounds(370, 133, 86, 14);
		contentPane.add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(507, 130, 121, 14);
		contentPane.add(textField_2);
		
		JLabel label_3 = new JLabel("Batch Number");
		label_3.setBounds(370, 161, 86, 14);
		contentPane.add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(507, 158, 121, 14);
		contentPane.add(textField_3);
		
		JLabel label_4 = new JLabel("Expiry Date");
		label_4.setBounds(370, 189, 79, 14);
		contentPane.add(label_4);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(507, 186, 114, 14);
		contentPane.add(textField_4);
		
		JLabel label_5 = new JLabel("Price");
		label_5.setBounds(370, 214, 79, 14);
		contentPane.add(label_5);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(507, 210, 93, 18);
		contentPane.add(textField_5);
		
		JLabel label_6 = new JLabel("Quantity");
		label_6.setBounds(370, 248, 110, 14);
		contentPane.add(label_6);
		
		textField_6 = new JTextField();
		textField_6.setBounds(507, 245, 86, 20);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Drug Entry");
		btnNewButton_2.setBounds(367, 293, 121, 41);
		contentPane.add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent y) {
				// TODO Auto-generated method stub
				if(y.getActionCommand().equals("Drug Entry"))
				{
					try{
						String dname=textField.getText();
						String ccompo=textField_1.getText();
						String brand=textField_2.getText();
						String bno=textField_3.getText();
						String edate=textField_4.getText();
						String price=textField_5.getText();
						String qty=textField_6.getText();
						Class.forName("com.mysql.jdbc.Driver");

				        //System.out.println("class for name");
				        java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb","root","");
				        java.sql.Statement s=con.createStatement();
				        String sql= "INSERT INTO drug_info VALUES ('"+dname+"','"+ccompo+"','"+brand+"','"+bno+"','"+edate+"','"+price+"','"+qty+"')";
				        //System.out.println(sql);
				        s.executeUpdate(sql);
				        JOptionPane.showMessageDialog(null,"Drug entry successfull!!");
				        textField.setText("");
				        textField_1.setText("");
				        textField_2.setText("");
				        textField_3.setText("");
				        textField_4.setText("");
				        textField_5.setText("");
				        textField_6.setText("");
				       
				        con.close();
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}
				
			}
			
		});
		
		JButton btnNewButton_3 = new JButton("Delete drug");
		btnNewButton_3.setBounds(507, 293, 121, 41);
		contentPane.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent x) {
				// TODO Auto-generated method stub
				if(x.getActionCommand().equals("Delete drug"))
	    		{
	    			try
	    			{ 
	    				String DNAME=textField.getText();
	    				Class.forName("com.mysql.jdbc.Driver");
	  		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb", "root", "");
	  		            
	  		            PreparedStatement st = con.prepareStatement("delete from drug_info where Drug_Name=?;");
	  		            
	  		          st.setString(1,DNAME);
	  		            
	  		         int val=st.executeUpdate();
	  		              
	  		        	 if (val==1)
	  		        		JOptionPane.showMessageDialog(null, "Drug deleted!");
	  		        	 
	  		        	textField.setText("");
	  		        	textField_1.setText("");
		                textField_2.setText("");
		                textField_3.setText("");
		                textField_4.setText("");
		                textField_5.setText("");
		                textField_6.setText("");
	  		         
	  		         System.out.println(val);
	  		       
	  		          con.close();
	    			}
	    			catch(Exception qe)
	    			{
	    				System.out.println(qe);
	    			}
	    		}
	    		
	    			
	    		
	    	
			}
			
		});
		
		JButton button = new JButton("Go");
		button.setBounds(631, 68, 51, 23);
		contentPane.add(button);
		button.addActionListener(new ActionListener(){
		
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getActionCommand().equals("Go"))
				{
				      try {
				            String str = textField.getText();
				         str.equalsIgnoreCase(str);
				 
				            Class.forName("com.mysql.jdbc.Driver");
				            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb", "root", "");
				            CallableStatement st = con.prepareCall("CALL dinfo(?)");
				            st.setString(1, str);
				            
				 
				           
				            ResultSet rs = st.executeQuery();
				           
				            //rs.next();
				         if (rs.next()) {
				                //String s = rs.getString(1);
				                String s1 = rs.getString(2);
				                String s2 = rs.getString(3);
				                String s3 = rs.getString(4);
				                String s4 = rs.getString(5);
				                String s5 = rs.getString(6);
				                String s6 = rs.getString(7);
				 
				                //Sets Records in TextFields.
				                textField_1.setText(s1);
				                textField_2.setText(s2);
				                textField_3.setText(s3);
				                textField_4.setText(s4);
				                textField_5.setText(s5);
				                textField_6.setText(s6);
				               
				            } else {
				            	
				                JOptionPane.showMessageDialog(null, "Drug not Found");
				                
				            }
				 
				            //Create Exception Handler
				        } catch (Exception ex) {
				 
				            System.out.println(ex);
				        }
				    }
				}
			
		});
		
		
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblUsername.setBounds(67, 72, 86, 19);
		contentPane.add(lblUsername);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(145, 72, 114, 19);
		contentPane.add(textField_7);
		JButton btnNewButton_4 = new JButton("Delete");
		btnNewButton_4.setBounds(100, 104, 89, 23);
		contentPane.add(btnNewButton_4);
	    btnNewButton_4.addActionListener(new ActionListener(){
	    	public void actionPerformed(ActionEvent e)
	    	{
	    		if(e.getActionCommand().equals("Delete"))
	    		{
	    			try
	    			{ 
	    				String UNAME=textField_7.getText();
	    				Class.forName("com.mysql.jdbc.Driver");
	  		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb", "root", "");
	  		            
	  		            PreparedStatement st = con.prepareStatement("delete from registeration where Username=?;");
	  		            
	  		          st.setString(1,UNAME);
	  		            
	  		         int val=st.executeUpdate();
	  		              
	  		        	 if (val==1)
	  		        		JOptionPane.showMessageDialog(null, "User deleted!");
	  		        	 else
	  		        		JOptionPane.showMessageDialog(null, "Username not found!");
	  		        	textField_7.setText("");
	  		         
	  		         System.out.println(val);
	  		       
	  		          con.close();
	    			}
	    			catch(Exception qe)
	    			{
	    				System.out.println(qe);
	    			}
	    		}
	    		
	    			
	    		
	    	}
	    });
		
		
		btnNewButton_1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
	  		       if(e.getActionCommand().equals("View drug database"))
	  		     {
	  		    	 try{
	  		    		 
	  		    		Class.forName("com.mysql.jdbc.Driver");
	  		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmadb?zeroDateTimeBehavior=convertToNull", "root", "");
	  		            
	  		            PreparedStatement st = con.prepareStatement("select Drug_Name,Chemical_Composition,Brand,Batch_Number,Expiry_Date,Price,QTY from drug_info;");
	  		            
	  		            
	  		          ResultSet rs = st.executeQuery();
	  		        JTable table = new JTable(buildTableModel(rs));
	  		        
	  		      JFrame frame=new JFrame();
	  	  	      frame.setVisible(true);
	  	  	      frame.getContentPane().add(new JScrollPane(table),BorderLayout.CENTER);
	  	  	  frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
	  	  	              con.close();
	  	  		
	  		    	 }
	  		    	 catch(Exception ee)
	  		    	 {
	  		    		 System.out.println(ee);
	  		    	 }
	  		     }
			}
			
			
			
		});
	
		
		}
	
	  public DefaultTableModel buildTableModel(ResultSet rs)
		        throws Exception {

		    java.sql.ResultSetMetaData metaData = rs.getMetaData();
		  

		    // names of columns
		    Vector<String> columnNames = new Vector<String>();
		    int columnCount = metaData.getColumnCount();
		    for (int column = 1; column <= columnCount; column++) {
		        columnNames.add(metaData.getColumnName(column));
		    }

		    // data of the table
		    Vector<Vector<Object>> data = new Vector<Vector<Object>>();
		    while (rs.next()) {
		        Vector<Object> vector = new Vector<Object>();
		        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
		            vector.add(rs.getObject(columnIndex));
		        }
		        data.add(vector);
		    }
		 
		  
	        

		    return new DefaultTableModel(data, columnNames);

		}
		
		
}